$(function() {
    $('.carousel').carousel('cycle');
});